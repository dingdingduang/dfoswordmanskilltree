package net.dingdingduang.dfoswordmanskilltree.dfoswdregistry.humanoidlayer;

import com.mojang.blaze3d.vertex.PoseStack;

import net.dingdingduang.dfoswordmanskilltree.dfoswdregistry.humanoidlayer.models.CommonModel;
import net.dingdingduang.dfoswordmanskilltree.dfoswdregistry.humanoidlayer.models.berserker.BloodSwordModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.LivingEntity;

import net.minecraft.world.entity.player.Player;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import net.dingdingduang.dfoswordmanskilltree.globalmethods.DfoSkillTreeItemMethods;
import net.dingdingduang.dfoswordmanskilltree.DfoSwordmanSkillTreeConstants;
import net.dingdingduang.dfoswordmanskilltree.dfoswdregistry.humanoidlayer.models.blademaster.KatanaModel;
import net.dingdingduang.dfoswordmanskilltree.dfoswdregistry.humanoidlayer.models.blademaster.LightsabreModel;
import net.dingdingduang.dfoswordmanskilltree.sbanimation.SBPlayerAnimatorMethods;
import net.dingdingduang.dfoswordmanskilltree.util.MathMethods;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static net.dingdingduang.dfoswordmanskilltree.globalmethods.DfoGeneralMethods.getMinecraftInstance;
import static net.dingdingduang.dfoswordmanskilltree.globalmethods.EntityMethods.getLivingEntityTickCount;
import static net.dingdingduang.somebasicskills.globalmethods.GeneralMethods.getMCResourceLocation;

public class SkillEffLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private final float WeaponHandOffsetY = 9.55F;

    private static final KatanaModel<LivingEntity> katanaOffhandModel = new KatanaModel<>(KatanaModel.createLeftOffHandLayer().bakeRoot());
    private static final LightsabreModel<LivingEntity> lightsabreOffhandModel = new LightsabreModel<>(LightsabreModel.createLeftOffHandLayer().bakeRoot());
    private static final BloodSwordModel<LivingEntity> bloodSwordOffhandModel = new BloodSwordModel<>(BloodSwordModel.createLeftOffHandLayer().bakeRoot());

    public SkillEffLayer(LivingEntityRenderer<T, M> pRenderer) {
        super(pRenderer);
//        this.katanaOffhandModel = new KatanaModel<>(KatanaModel.createLeftOffHandLayer().bakeRoot());
//        this.lightsabreOffhandModel = new LightsabreModel<>(LightsabreModel.createLeftOffHandLayer().bakeRoot());
    }

    private static final Set<String> KatanaActionNameSet = Set.of(
            "sword_act_katana_slash4to1", "sword_act_katana_slash1to2", "sword_act_katana_slash2to3", "sword_act_katana_slash3to4", "sword_act_katana_1"
    );

    private static final Set<String> LightsabreActionNameSet = Set.of(
            "sword_act3to1_slash", "sword_act1to2_slash", "sword_act2to3_slash", "sword_act1"
    );

    private static final Set<String> BloodSwordActionNameSet = Set.of(
            "frenzy_attack_slash_1", "frenzy_attack_slash_2", "frenzy_attack_slash_3", "frenzy_attack_slash_4"
    );

    private static final Map<String, CommonModel<LivingEntity>> ActionNameMap = Map.ofEntries(
            Map.entry("sword_act_katana_slash4to1", katanaOffhandModel),
            Map.entry("sword_act_katana_slash1to2", katanaOffhandModel),
            Map.entry("sword_act_katana_slash2to3", katanaOffhandModel),
            Map.entry("sword_act_katana_slash3to4", katanaOffhandModel),
            Map.entry("sword_act_katana_1", lightsabreOffhandModel),
            Map.entry("sword_act3to1_slash", lightsabreOffhandModel),
            Map.entry("sword_act1to2_slash", lightsabreOffhandModel),
            Map.entry("sword_act2to3_slash", lightsabreOffhandModel),
            Map.entry("frenzy_attack_slash_1", bloodSwordOffhandModel),
            Map.entry("frenzy_attack_slash_2", bloodSwordOffhandModel),
            Map.entry("frenzy_attack_slash_3", bloodSwordOffhandModel),
            Map.entry("frenzy_attack_slash_4", bloodSwordOffhandModel)
    );

    public static void displayLayerModel(LivingEntity livingEntity, HumanoidModel<LivingEntity> layerModel) {
        EntityRenderer<? super LivingEntity> entityRenderer = getMinecraftInstance().getEntityRenderDispatcher().getRenderer(livingEntity);
        if (entityRenderer instanceof LivingEntityRenderer<?, ?> livingRenderer) {
            EntityModel<?> entityModel = livingRenderer.getModel();

            if (entityModel instanceof HumanoidModel<?> humanoidModel) {
                if (layerModel instanceof CommonModel<?> commonModel) {
                    commonModel.setTempLeftHand(humanoidModel.leftArm);
                }
            }
        }
    }

    @Override
    public void render(PoseStack pPoseStack, MultiBufferSource bufferSource, int packedLight, T pLivingEntity, float pLimbSwing, float pLimbSwingAmount, float pPartialTicks, float pAgeInTicks, float pNetHeadYaw, float pHeadPitch) {
        pPoseStack.pushPose();

        //Blademaster021 offhand weapon
        if (pLivingEntity instanceof Player player && DfoSkillTreeItemMethods.isOffhandEmpty(pLivingEntity)) {
            if (SBPlayerAnimatorMethods.getPlayerLastAnimPlayer(player) != null && SBPlayerAnimatorMethods.getPlayerLastAnimPlayer(player).isActive()) {
                //init
                ModelPart bone;
                String LastPlayerAnimName = SBPlayerAnimatorMethods.getPlayerLastAnimationName(player);

                CommonModel<LivingEntity> OffHandModel = ActionNameMap.get(LastPlayerAnimName);
                if (OffHandModel != null) {
                    displayLayerModel(pLivingEntity, OffHandModel);
                    bone = OffHandModel.getTempLeftHand();
                    setupTranslation(pPoseStack, bufferSource, pLivingEntity, bone, OffHandModel, OffHandModel.getOffhandTexture(), OffHandModel.getScale(), OffHandModel.getGlint());
                }
            }
        }



        pPoseStack.popPose();
    }

    public void setupTranslation(PoseStack pPoseStack, MultiBufferSource bufferSource, T pLivingEntity, ModelPart bone, HumanoidModel<LivingEntity> humanoidModel, ModelLayerLocation modelLayerLocation, float scale, float glint) {
        pPoseStack.pushPose();
        pPoseStack.translate(bone.x * DfoSwordmanSkillTreeConstants.OneOver16, bone.y * DfoSwordmanSkillTreeConstants.OneOver16, bone.z * DfoSwordmanSkillTreeConstants.OneOver16);

        setupRotation(pPoseStack, bufferSource, pLivingEntity, bone, humanoidModel, modelLayerLocation, scale, glint);
        pPoseStack.popPose();
    }

    public void setupRotation(PoseStack pPoseStack, MultiBufferSource bufferSource, T pLivingEntity, ModelPart bone, HumanoidModel<LivingEntity> humanoidModel, ModelLayerLocation modelLayerLocation, float scale, float glint) {
        pPoseStack.pushPose();

        Quaternionf rotator;
        if (bone.zRot != 0) {
            rotator = new Quaternionf();
            Vector3f AxisZN = new Vector3f(0, 0, 1);
            rotator.rotationAxis(bone.zRot, AxisZN);
            pPoseStack.rotateAround(rotator, 0, 0, 0);
//            rotator.rotationAxis(bone.zRot, AxisZN);
//            pPoseStack.rotateAround(rotator, 0, 0, testPressKeyTranslateRot.tempFloatNewRotZ);
        }

        if (bone.yRot != 0) {
            rotator = new Quaternionf();
            Vector3f AxisYP = new Vector3f(0, 1, 0);
            rotator.rotationAxis(bone.yRot, AxisYP);
//            pPoseStack.rotateAround(rotator, 0, testPressKeyTranslateRot.tempFloatNewRotY, 0);
            pPoseStack.rotateAround(rotator, 0, 0, 0);
        }

        if (bone.xRot != 0) {
            rotator = new Quaternionf();
            Vector3f AxisXN = new Vector3f(1, 0, 0);
            rotator.rotationAxis(bone.xRot, AxisXN);
//            pPoseStack.rotateAround(rotator, testPressKeyTranslateRot.tempFloatNewRotX, 0, 0);
            pPoseStack.rotateAround(rotator, 0, 0, 0);
        }

        finalRenderItem(pPoseStack, bufferSource, pLivingEntity, bone, humanoidModel, modelLayerLocation, scale, glint);
        pPoseStack.popPose();
    }

    public void finalRenderItem(PoseStack pPoseStack, MultiBufferSource bufferSource, T pLivingEntity, ModelPart bone, HumanoidModel<LivingEntity> humanoidModel, ModelLayerLocation modelLayerLocation, float scale, float glint) {
        pPoseStack.pushPose();


//        pPoseStack.translate(testPressKeyTranslateRot.tempFloatNewX * DfoSwordmanSkillTreeConstants.OneOver16, WeaponHandOffsetY * DfoSwordmanSkillTreeConstants.OneOver16, testPressKeyTranslateRot.tempFloatNewZ * DfoSwordmanSkillTreeConstants.OneOver16);
        pPoseStack.translate(0, WeaponHandOffsetY * DfoSwordmanSkillTreeConstants.OneOver16, 0);

        pPoseStack.pushPose();

        Quaternionf rotator;

//        rotator = new Quaternionf();
//        Vector3f AxisZN = new Vector3f(0, 0, -1);
//        rotator.rotationAxis(MathMethods.AngleToRadiansNoRound(testPressKeyTranslateRot.tempFloatNewRotZ), AxisZN);
//        pPoseStack.rotateAround(rotator, 0, 0, 0);
//
//        rotator = new Quaternionf();
//        Vector3f AxisYP = new Vector3f(0, 1, 0);
//        rotator.rotationAxis(MathMethods.AngleToRadiansNoRound(testPressKeyTranslateRot.tempFloatNewRotY), AxisYP);
//        pPoseStack.rotateAround(rotator, 0, 0, 0);
//
//        rotator = new Quaternionf();
//        Vector3f AxisXN = new Vector3f(-1, 0, 0);
//        rotator.rotationAxis(MathMethods.AngleToRadiansNoRound(testPressKeyTranslateRot.tempFloatNewRotX), AxisXN);
//        pPoseStack.rotateAround(rotator, 0, 0, 0);

        rotator = new Quaternionf();
        Vector3f AxisZN = new Vector3f(0, 0, -1);
        rotator.rotationAxis(MathMethods.HALF_PI, AxisZN);
        pPoseStack.rotateAround(rotator, 0, 0, 0);

//        rotator = new Quaternionf();
//        Vector3f AxisYP = new Vector3f(0, 1, 0);
//        rotator.rotationAxis(0, AxisYP);
//        pPoseStack.rotateAround(rotator, 0, 0, 0);

        rotator = new Quaternionf();
        Vector3f AxisXN = new Vector3f(-1, 0, 0);
        rotator.rotationAxis(-MathMethods.HALF_PI, AxisXN);

        if (scale != 1.0F) {
            rotator.scale(scale);
        }

        pPoseStack.rotateAround(rotator, 0, 0, 0);


        humanoidModel.renderToBuffer(pPoseStack, bufferSource.getBuffer(RenderType.entityTranslucentCull(modelLayerLocation.getModel())), LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, ( (1.0F - glint) + glint * (MathMethods.cos(getLivingEntityTickCount(pLivingEntity) * 0.1F))));


        pPoseStack.popPose();

        pPoseStack.popPose();
    }
}
