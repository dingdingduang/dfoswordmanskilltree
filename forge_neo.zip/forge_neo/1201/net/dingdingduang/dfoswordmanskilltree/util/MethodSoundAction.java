package net.dingdingduang.dfoswordmanskilltree.util;

import net.minecraft.world.level.Level;

public interface MethodSoundAction {
    void executeSoundAction(Level worldLevel, double x1, double y1, double z1, float volume, float pitch);
}
