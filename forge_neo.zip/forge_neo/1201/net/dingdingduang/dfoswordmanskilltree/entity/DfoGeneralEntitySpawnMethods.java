package net.dingdingduang.dfoswordmanskilltree.entity;

import net.dingdingduang.dfoswordmanskilltree.entity.clientmovementhelper.ClientMovementHelper;
import net.dingdingduang.dfoswordmanskilltree.geomodel.GeoModelRegistryName;
import net.dingdingduang.dfoswordmanskilltree.geomodel.GeoModelSpawnMethods;
import net.dingdingduang.dfoswordmanskilltree.geomodel.models.nullrenderer.clientparticlehelper.ClientParticleHelperEntity;
import net.dingdingduang.somebasicskills.util.MethodEntityAction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;

import net.dingdingduang.dfoswordmanskilltree.DfoSwordmanSkillTreeConstants;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

import java.util.function.Function;

import static net.dingdingduang.dfoswordmanskilltree.globalmethods.DfoGeneralMethods.printInGameMsg;
import static net.dingdingduang.dfoswordmanskilltree.globalmethods.EntityMethods.*;

public class DfoGeneralEntitySpawnMethods {
    public static Entity MCLoadEntityRecursive(CompoundTag pCompound, Level pLevel, Function<Entity, Entity> pEntityFunction) {
        return EntityType.loadEntityRecursive(pCompound, pLevel, pEntityFunction);
    }

    public static ClientMovementHelper SetupClientMovementHelper(Entity owner, int maxLifetime,
                                                                 boolean hasTargetLoc, float startX, float startY, float startZ,
                                                                 float targetX, float targetY, float targetZ,
                                                                 String ClientActionName, MethodEntityAction serverEntityAction, int serverEntityActionTickPeriod, boolean addEntityToWorldRightAway) {
        String entityID = DfoSwordmanSkillTreeConstants.MOD_ID + GeoModelRegistryName.COLON + DfoMinecraftDefaultEntitiesRegistryConstants.CLIENT_MOVEMENT_HELPER_STR_ID;

        CompoundTag nbtEntityTag = GeoModelSpawnMethods.getEntityIDTag(entityID);

        ClientMovementHelper Entity000 = (ClientMovementHelper) MCLoadEntityRecursive(nbtEntityTag, getEntityLevel(owner), (tempEntity) -> {
            moveEntityToXYZRotation(tempEntity, startX, startY, startZ, 0f, 0f);
            return tempEntity;
        });

        Entity000.setLifetime(maxLifetime);
        Entity000.setMaxLifetime(maxLifetime);
        Entity000.setOwner(owner);
        if (hasTargetLoc) {
            Entity000.setTargetLoc(startX, startY, startZ, targetX, targetY, targetZ, true);
        }
        Entity000.setClientActionName(ClientActionName);
        Entity000.setEntityServerAction(serverEntityAction, serverEntityActionTickPeriod);

        if (addEntityToWorldRightAway) {
            addEntityToWorld(getEntityLevel(owner), Entity000);
        }
        return Entity000;
    }

    public static ClientParticleHelperEntity SetupClientParticleHelper(Entity owner, float horizontalFacing, float verticalFacing, int maxLifetime, boolean isBoundToEntity,
                                                                       boolean hasTargetLoc, float startX, float startY, float startZ,
                                                                       float targetX, float targetY, float targetZ,
                                                                       String ClientActionName, String ParticleActionName, MethodEntityAction serverEntityAction, int serverEntityActionTickPeriod, boolean addEntityToWorldRightAway) {
        String entityID = DfoSwordmanSkillTreeConstants.MOD_ID + GeoModelRegistryName.COLON + GeoModelRegistryName.CLIENT_PARTICLE_HELPER_STR_ID;

        CompoundTag nbtEntityTag = GeoModelSpawnMethods.getEntityIDTag(entityID);

        ClientParticleHelperEntity Entity000 = (ClientParticleHelperEntity) MCLoadEntityRecursive(nbtEntityTag, getEntityLevel(owner), (tempEntity) -> {
            moveEntityToXYZRotation(tempEntity, startX, startY, startZ, horizontalFacing, verticalFacing);
            return tempEntity;
        });

        Entity000.setLifetime(maxLifetime);
        Entity000.setMaxLifetime(maxLifetime);
        Entity000.setOwner(owner);
        if (isBoundToEntity) {
            Entity000.setIsBoundToEntity(isBoundToEntity);
        }
        if (hasTargetLoc) {
            Entity000.setTargetLoc(startX, startY, startZ, targetX, targetY, targetZ, true);
        }
        Entity000.setClientActionName(ClientActionName);
        Entity000.setParticleName(ParticleActionName);
        Entity000.setEntityServerAction(serverEntityAction, serverEntityActionTickPeriod);

        if (addEntityToWorldRightAway) {
            addEntityToWorld(getEntityLevel(owner), Entity000);
        }
        return Entity000;
    }

    public static ClientParticleHelperEntity SetupClientParticleHelperNoLoc(Entity owner, float horizontalFacing, float verticalFacing, int maxLifetime, float x, float y, float z,
                                                                            String ClientActionName, String ParticleActionName, MethodEntityAction serverEntityAction, int serverEntityActionTickPeriod, boolean addEntityToWorldRightAway) {
        return SetupClientParticleHelper(owner, horizontalFacing, verticalFacing, maxLifetime, false, false, x, y, z, x, y, z, ClientActionName, ParticleActionName, serverEntityAction, serverEntityActionTickPeriod, addEntityToWorldRightAway);
    }

    public static ClientParticleHelperEntity SetupClientParticleHelperBoundToEntity(Entity owner, float horizontalFacing, float verticalFacing, int maxLifetime,
                                                                                    String ClientActionName, String ParticleActionName, MethodEntityAction serverEntityAction, int serverEntityActionTickPeriod, boolean addEntityToWorldRightAway) {
        return SetupClientParticleHelper(owner, horizontalFacing, verticalFacing, maxLifetime, true, false, getEntityX(owner), getEntityY(owner), getEntityZ(owner), getEntityX(owner), getEntityY(owner), getEntityZ(owner), ClientActionName, ParticleActionName, serverEntityAction, serverEntityActionTickPeriod, addEntityToWorldRightAway);
    }

    public static ClientParticleHelperEntity SetupClientParticleHelperFromLocAToLocB(Entity owner, float horizontalFacing, float verticalFacing, int maxLifetime, float startX, float startY, float startZ,
                                                                                    float targetX, float targetY, float targetZ,
                                                                                    String ClientActionName, String ParticleActionName, MethodEntityAction serverEntityAction, int serverEntityActionTickPeriod, boolean addEntityToWorldRightAway) {
        return SetupClientParticleHelper(owner, horizontalFacing, verticalFacing, maxLifetime, false, true, startX, startY, startZ, targetX, targetY, targetZ, ClientActionName, ParticleActionName, serverEntityAction, serverEntityActionTickPeriod, addEntityToWorldRightAway);
    }

    public static ClientMovementHelper SetupClientMovementHelper(Entity owner, int maxLifetime,
                                                                 Vector3f startPos, Vector3f targetPos,
                                                                 String ClientActionName, MethodEntityAction serverEntityAction, int serverEntityActionTickPeriod, boolean addEntityToWorldRightAway) {
        return SetupClientMovementHelper(owner, maxLifetime, true, startPos.x(), startPos.y(), startPos.z(), targetPos.x(), targetPos.y(), targetPos.z(), ClientActionName, serverEntityAction, serverEntityActionTickPeriod, addEntityToWorldRightAway);
    }
}
