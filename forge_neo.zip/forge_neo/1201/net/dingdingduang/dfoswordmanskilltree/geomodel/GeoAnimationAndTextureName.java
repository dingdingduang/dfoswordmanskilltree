package net.dingdingduang.dfoswordmanskilltree.geomodel;

public final class GeoAnimationAndTextureName {
    //sword slash
    public static final String NO_ANIMATION_CUSTOM_SWORD_SLASH_Z12_XPR15 = "noaction_translatationZ12_XPR15";
    public static final String NO_ANIMATION_CUSTOM_SWORD_SLASH_Z24_XPR15 = "noaction_translatationZ24_XPR15";
    public static final String NO_ANIMATION_CUSTOM_SWORD_SLASH_Z36_XPR15 = "noaction_translatationZ36_XPR15";
    public static final String NO_ANIMATION_CUSTOM_SWORD_SLASH_Z48_XPR15 = "noaction_translatationZ48_XPR15";

    //2D
    public static final String NO_ANIMATION_TRANSLATION_XP_8 = "noaction_translatationXP8";
    public static final String NO_ANIMATION_TRANSLATION_XN_8 = "noaction_translatationXN8";
    public static final String NO_ANIMATION_TRANSLATION_Z_24 = "noaction_translatationZ24";
    public static final String NO_ANIMATION_TRANSLATION_Z_36 = "noaction_translatationZ36";
    public static final String NO_ANIMATION_TRANSLATION_Z_48 = "noaction_translatationZ48";
    public static final String NO_ANIMATION_TRANSLATION_Y_22_4 = "noaction_translatationY22_4";
    public static final String NO_ANIMATION_TRANSLATION_Y_24 = "noaction_translatationY24";
    public static final String NO_ANIMATION_TRANSLATION_Y_36 = "noaction_translatationY36";
    public static final String NO_ANIMATION_TRANSLATION_Y_48 = "noaction_translatationY48";

    public static final String ENTITY_2D_TEX_COMMON_TRAIL = "textures/entity/skilleff/common/trail/";
    public static final String ROTATE_2D_ENTITY_FRONT_180_10TICKS_R2L = "rotatefront180fromrighttoleft_10ticks_fast";
    public static final String ROTATE_2D_ENTITY_FRONT_180_10TICKS_L2R = "rotatefront180fromlefttoright_10ticks_fast";
    public static final String ROTATE_2D_ENTITY_CLOCKWISE_1080 = "rotate_spin_clockwise_1080";
    public static final String ROTATE_2D_ENTITY_XP_20 = "rotate_xp_20";
    public static final String ROTATE_2D_ENTITY_XP_340 = "rotate_xp_340";

    //flat 2d animation
    public static final String Rotate_2D_FLAT_ENTITY_360_CLOCKWISE_IN_5_TICKS = "rotate_360_in_5_ticks";
    //model texture
    public static final String BLUDGEON_HIT_SPIRAL = "textures/entity/skilleff/common/spiral/";


    public static final String EFF_COMMON_CHARGING_LOOPING = "textures/entity/skilleff/common/charging/loop/";
    public static final String EFF_COMMON_CHARGING_MAX_OUT = "textures/entity/skilleff/common/charging/maxout/";
    public static final String EFF_HIT_GENERAL = "textures/entity/skilleff/common/hitdamage/";
    public static final String[] EFF_HIT_EFF_ADVANCE_ARR = {EFF_HIT_GENERAL, "textures/entity/skilleff/blademaster/sense_slash/hit_eff1/", "textures/entity/skilleff/blademaster/sense_slash/hit_eff2/"};
    public static final String EFF_ENTITY_ANIMATION_NAME_STAB = "stab";
    public static final String EFF_ENTITY_TEX_BLADEMASTER_STAB = "textures/entity/skilleff/blademaster/stab/";
    public static final String EFF_ENTITY_TEX_BLADEMASTER_FANCY_SLASH_FLAME = "textures/entity/skilleff/blademaster/fancyslash/flame/";
    public static final String EFF_ENTITY_TEX_BLADEMASTER_FANCY_SLASH_WHITE = "textures/entity/skilleff/blademaster/fancyslash/white/";
    public static final String EFF_ENTITY_TEX_BLADEMASTER_FANCY_SLASH_WHITE_WITHOUT_START_FRAME = "textures/entity/skilleff/blademaster/fancyslash/white_no_start_frame/";
    public static final String EFF_ENTITY_TEX_COMMON_CHARGING_ALL = "textures/entity/skilleff/common/charging/all/";
    public static final String EFF_ENTITY_TEX_FADING_CLONE = "textures/entity/skilleff/common/fadingclone/";

    //=====================
    //eff texture path
    public static final String EFF_RECOVERY_TEXTURE_PATH = "textures/entity/skilleff/common/healing/";
    public static final String EFF_SLASH_ANIMATION_NAME_NO_ACTION_NEG_Z16 = "noaction_translation_negz16";
    public static final String EFF_SLASH_ANIMATION_NAME_NEG30_2_POS60 = "start_slash_neg30_2_pos60";
    public static final String EFF_SLASH_ANIMATION_NAME_NEG60_2_POS15 = "start_slash_neg60_2_pos15";

    //channeling and icon
//    public static final String CHANNELING_BAR_EMPTY = "progressbar_empty";
    public static final String CHANNELING_BAR_FILLING = "progressbar_filling";
//    public static final String CHANNELING_BAR_FULL = "progressbar_full";
    public static final String CHANNELING_BAR_FILLING_Y_180DEG = "progressbar_filling_rotate_y_deg_180";

    public static final String ICON_ENTITY_ANIMATION_NO_ACTION = "noaction";
    public static final String ICON_ENTITY_ANIMATION_Y_180DEG = "noaction_flip_y180deg";
}
