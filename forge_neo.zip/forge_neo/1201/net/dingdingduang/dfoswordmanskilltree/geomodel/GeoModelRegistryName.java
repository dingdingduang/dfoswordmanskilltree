package net.dingdingduang.dfoswordmanskilltree.geomodel;

public final class GeoModelRegistryName {
    public static final String COLON = ":";

    public static final String ENTITY_NO_TEXTURE = "textures/entity/no_texture_256.png";

    public static final String CLIENT_PARTICLE_HELPER_STR_ID = "clientparticlehelper";
    //2D tex
    public static final String ENTITY_2D_64PX_ICON_NBT_NAME = "twodentity";

    public static final String ENTITY_2D_ANIMATED_64PX_NBT_NAME = "twodanimatedtexsixfourentity";
    public static final String ENTITY_2D_ANIMATED_128PX_NBT_NAME = "twodanimatedtexonetwoeightentity";
    public static final String ENTITY_2D_ANIMATED_256PX_NBT_NAME = "twodanimatedtextwofivesixentity";

    public static final String ENTITY_2D_ANIMATED_64PX_FIXED_YAXIS_NBT_NAME = "twodanimatedtexsixfourmanipulateyentity";
    public static final String ENTITY_2D_ANIMATED_128PX_FIXED_YAXIS_NBT_NAME = "twodanimatedtexonetwoeightmanipulateyentity";
    public static final String ENTITY_2D_ANIMATED_256PX_FIXED_YAXIS_NBT_NAME = "twodanimatedtextwofivesixmanipulateyentity";

    public static final String ENTITY_2D_256PX_CUSTOM_NBT_NAME = "dfoswordtwodtexcustomtwofivesix";
    public static final String ENTITY_2D_256PX_COLOR_CUSTOM_NBT_NAME = "dfoswordtwodtexrgbtwofivesix";
    public static final String ENTITY_2D_256PX_CUSTOM_TOTAL_FRAME_ONLY_NBT_NAME = "dfoswordtwodtextotalframetwofivesix";

    public static final String ENTITY_2D_256PX_CUSTOM_FLAT_NBT_NAME = "dfoswordtwodtexcustomflattwofivesix";

    public static final String ENTITY_CHANNELING_BAR = "dfochannelingbar";
    public static final String ENTITY_CHANNELING_BAR_TEXTURE = "textures/entity/skilleff/common/channelingbar/progressbar_merge.png";
    public static final String ENTITY_CHANNELING_ICON = "dfochannelingicon";


    //blademaster slash
    public static final String SWD_FLOATING_SWORD = "dfoswordmanfloatingsword";

    public static final String SWD_SLASH_YELLOW = "dfoswordslashyellowdummy";
    public static final String SWD_SLASH_PURPLE = "dfoswordslashpurpledummy";
    public static final String SWD_SLASH_WHITE = "dfoswordslashwhitedummy";
    public static final String SWD_FANCY_SLASH_CUSTOM = "dfoswordslashcustomdummy";
    public static final String SWD_FANCY_SLASH_CUSTOM_TOTAL_FRAME_ONLY = "dfoswordslashcustomtotalframedummy";

    //eff
    public static final String EFF_TARGET_ZONE = "efftargetzoneselection";
    public static final String EFF_HIT = "effhit";

    public static final String EFF_BUFF = "effbuff";
    public static final String EFF_BUFF_ALT = "effbuffalt";
    public static final String EFF_STAB = "effstab";
    public static final String EFF_STRIKE_FROM_AIR = "effstrikeair";
    public static final String EFF_GROUND_QUAKE = "effgroundquake";

    public static final String EFF_SWD_FADING_CLONE_ENTITY_NBT_NAME = "efffadingclone";

    public static final String EFF_SWD_TEMPEST_BLOCK = "effswdtempestblock";
    public static final String EFF_SWD_TEMPEST_SWORD = "effswdtempestsword";
    public static final String EFF_SWD_DRAW_SWORD_QI = "effswddrawswordqi";
    public static final String EFF_SWD_SIMPLE_MC_SWORD = "effsimplemcsword";
    public static final String EFF_SWD_FANCY_SWORD = "efffancysword";
    public static final String EFF_SWD_SLAUGHTER_SCAPE_SWORD = "effswdslaughterscapesword";
}
